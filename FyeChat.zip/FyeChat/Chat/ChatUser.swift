//
//  ChatUser.swift
//  FyeChat
//
//  Created by Dameion on 1/15/23.
//

import Foundation
import UIKit
import MessageKit


struct ChatUser: SenderType, Equatable {
    
    var senderId: String
    var displayName: String
    
}

