//
//  SignUpVC.swift
//  FyeChat
//
//  Created by Dameion on 1/15/23.
//

import Foundation
import UIKit
import FirebaseAuth
import Firebase

class SignUpVC : UIViewController {
    
    @IBOutlet weak var firstNameTF: UITextField!
    @IBOutlet weak var lastNameTF: UITextField!
    
    @IBOutlet weak var emailTF: UITextField!
    @IBOutlet weak var passwordTF: UITextField!
    
    @IBOutlet weak var signUpButton: UIButton!
    @IBOutlet weak var errorLabel: UILabel!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        setUpElements()
        
    }

    func setUpElements() {
        
        
        //hiding error label
        errorLabel.alpha = 0
        
        
        //throwing some style on'num
        Utilities.styleTextField(firstNameTF)
        Utilities.styleTextField(lastNameTF)
        
        Utilities.styleTextField(emailTF)
        Utilities.styleTextField(passwordTF)

        Utilities.styleFilledButton(signUpButton)
        
    }
    
    
    
    //this is validating if the data is correct
    func validateFields() -> String? {
        
        //checks if all fields are filled in
        if firstNameTF.text?.trimmingCharacters(in: .whitespacesAndNewlines) == "" || lastNameTF.text?.trimmingCharacters(in: .whitespacesAndNewlines) == "" ||
            emailTF.text?.trimmingCharacters(in: .whitespacesAndNewlines) == "" ||
            passwordTF.text?.trimmingCharacters(in: .whitespacesAndNewlines) == "" {
            
            return "Please fill in all fields."
        }
        
        //checks if its secure
        let cleanedPassword = passwordTF.text!.trimmingCharacters(in: .whitespacesAndNewlines)
        
        
        if (Utilities.isPasswordValid(cleanedPassword) == false){
            
            return "Please make sure your password is at least 8 characters, contains special character and a number. "
            
        }
        
        return nil
        
    }

    @IBAction func signUpTapped(_ sender: Any) {
        
        //validate fields
        let error = validateFields()
        
        
        if error != nil {
            
            
            //there's something wrong with the fields
            showError(error!)
        }
        else {
            
            //create cleaned versions of the data
            let firstName = firstNameTF.text!.trimmingCharacters(in: .whitespacesAndNewlines)
            let lastName = lastNameTF.text!.trimmingCharacters(in: .whitespacesAndNewlines)
            let email = emailTF.text!.trimmingCharacters(in: .whitespacesAndNewlines)
            let password = passwordTF.text!.trimmingCharacters(in: .whitespacesAndNewlines)
            
            
            // create the user
            Auth.auth().createUser(withEmail: email, password: password) { (result, err) in
                
                //check for errors
                if err != nil {
                    //there was an error creating the user
                    self.showError("Error creating user")
                }
                else {
                    
                    //User created successfully, now store the first name and last name
                    let db = Firestore.firestore()
                    
                    db.collection("users").addDocument(data: ["firstName":firstName, "lastName":lastName, "uid": result!.user.uid]){(error ) in
                        
                        if error != nil {
                            self.showError("error saving user data")
                        }
                    }
                    
                }
                
                
            }
            
            // transition to the home screen
            self.transitionToHome()
            
        }
        

        
        
        
        
    }
    
    
    
    
    func showError(_ message: String) {
        
        errorLabel.text = message
        errorLabel.alpha = 1
    }
    
    func transitionToHome(){
        
        let homeViewController = storyboard?.instantiateViewController(withIdentifier: Constants.Storyboard.homeVC) as? HomeVC
        
        
        view.window?.rootViewController = homeViewController
        view.window?.makeKeyAndVisible()
        
    }
    
    
}
