//
//  NavController.swift
//  FyeChat
//
//  Created by Dameion on 1/13/23.
//

import Foundation

import UIKit

class NavController : UIViewController {

    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        //GIDSignIn.sharedInstance()?.presentingViewController = self

    }


}
