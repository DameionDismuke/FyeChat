//
//  LoginVC.swift
//  FyeChat
//
//  Created by Dameion on 1/13/23.
//

import Foundation
import UIKit
import FirebaseAuth
import Firebase

class LoginVC : UIViewController {

    @IBOutlet weak var emailTF: UITextField!
    @IBOutlet weak var passwordTF: UITextField!
    @IBOutlet weak var loginTF: UIButton!
    
    @IBOutlet weak var errorLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()


        setUpElements()
        
        
    }
    
    func setUpElements(){
        
        
        //making error label invisible
        errorLabel.alpha = 0
        
        
        //stylin on dem Elements, hommie!
        Utilities.styleTextField(emailTF)
        Utilities.styleTextField(passwordTF)
        
        Utilities.styleFilledButton(loginTF)
        
        
    }


    @IBAction func loginTapped(_ sender: Any) {
        
        //validate text fields
        
        
        
        //create the clean versions
        let email = emailTF.text!.trimmingCharacters(in: .whitespacesAndNewlines)
        let password = passwordTF.text!.trimmingCharacters(in: .whitespacesAndNewlines)
        
        //logging in the user
        Auth.auth().signIn(withEmail: email, password: password){ (result, error) in
            
            
            if error != nil {
                //if couldnt sign in
                self.errorLabel.text = error!.localizedDescription
                self.errorLabel.alpha = 1
                
            }
            else {
                
                let homeViewController = self.storyboard?.instantiateViewController(withIdentifier: Constants.Storyboard.homeVC) as? HomeVC
                
                self.view.window?.rootViewController = homeViewController
                self.view.window?.makeKeyAndVisible()
                
            }
        }
    }
    

}
