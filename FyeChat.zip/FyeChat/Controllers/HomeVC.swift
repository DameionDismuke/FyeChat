//
//  HomeVC.swift
//  FyeChat
//
//  Created by Dameion on 1/15/23.
//

import Foundation
import UIKit

class HomeVC : UIViewController {

    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()


        
        
    }


}
