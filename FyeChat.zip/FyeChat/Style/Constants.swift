//
//  Constants.swift
//  FyeChat
//
//  Created by Consultant on 1/15/23.
//

import Foundation



struct Constants {
    
    
    struct Storyboard {
        
        static let homeVC = "HomeVC"
    }
    
    
}
